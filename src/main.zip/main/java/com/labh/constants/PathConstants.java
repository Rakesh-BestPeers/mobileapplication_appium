package com.labh.constants;

import java.io.File;

public interface PathConstants {

	
    //artifacts
    String screenshots = "artifacts" + File.separator + "Screenshots";
    String reports = "artifacts" + File.separator + "html";
    //String cucumberReports = "artifacts" + File.separator + "html"+ File.separator +"Extent";
    String video = "artifacts" + File.separator + "Videos";
    String severlogs = "artifacts" + File.separator + "Severlogs";
    String logs = "artifacts" + File.separator + "logs";

    //testdata
    String testData = "./src/test/resources/data/DataSheet.xlsx";
    String xmlPath = "strings/strings.xml";
    String jsonPath = "data/loginUsers.json";
    String toastMsg = "artifacts" + File.separator + "verifyScreenShots";
    
    //changes done by Mohit on 8-Oct-2020
    String downloadImgPath = System.getProperty("user.dir")+"//src//test//resources//imageDownloaded//elips.svg";
    String storedImgPath = System.getProperty("user.dir")+"//src//test//resources//imageStored//";
}

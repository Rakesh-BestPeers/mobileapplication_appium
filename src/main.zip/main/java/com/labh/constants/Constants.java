package com.labh.constants;

public interface Constants {
	
	public boolean isAWS = false;
	public boolean isServer = true;
	
	public String appiumServerURL = "http://127.0.0.1:4723/wd/hub";

	//public String url = "http://54.184.98.141:3000/login";
	public String url ="https://dev.letsallbeheard.com/login";
	public String platformName ="Android";
	public String platformVersion = "9.0";
	public String udid = "emulator-5554";
	public String apppackage = "letsallapp.labh.stage";
	public String weburl = "https://stage.letsallbeheard.com/login";
	public String appactivity ="‪letsallapp.activity.MainActivity";
	 public String AndroidAppUrl ="C:\\Users\\Vikrant.Gaurav\\Downloads\\app-labhStage29DecV1.apk";

}

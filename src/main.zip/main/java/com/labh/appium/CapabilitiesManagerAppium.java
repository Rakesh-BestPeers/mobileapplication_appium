package com.labh.appium;

import io.appium.java_client.remote.MobileCapabilityType;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.labh.constants.Constants;
import com.labh.utils.PropertyManager;
import com.labh.utils.TestUtils;

import java.io.File;
import java.io.IOException;
import java.util.Properties;



public class CapabilitiesManagerAppium {
	TestUtils utils = new TestUtils();
	public DesiredCapabilities getCaps() throws IOException {
//		GlobalParamsAppium params = new GlobalParamsAppium();
//		Properties props = new PropertyManager().getProps();
//
//		
//		
//		try{
//			utils.log().info("getting capabilities");
//			DesiredCapabilities caps = new DesiredCapabilities();
//			caps.setCapability(MobileCapabilityType.PLATFORM_NAME, params.getPlatformName());
//			caps.setCapability(MobileCapabilityType.UDID, params.getUDID());
//			caps.setCapability(MobileCapabilityType.DEVICE_NAME, params.getDeviceName());
//			//caps.setCapability("chromedriverExecutable",
//			//	"D:\\chrome\\chromedriver_win32\\chromedriver.exe");		
//			
//			switch(params.getPlatformName()){
//			case "Android":
//				caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, props.getProperty("android.automationName"));
//				if(!Constants.isAWS) {
//					
//					
//				
//				
//				
//				/*//	caps.setCapability("appWaitActivity", Constants.appactivity); 
//				   caps.setCapability("appPackage", Constants.apppackage);
//				 //  caps.setCapability("appActivity", Constants.appactivity);
//				   caps.setCapability("appWaitActivity", "Constants.apppackage");
//					caps.setCapability("platformName",  Constants.platformName);
//					caps.setCapability("platformVersion",  Constants.platformVersion);*/
//					
//					
//					
//					
//					
//					caps.setCapability("platformName", "Android");
//					caps.setCapability("deviceName", "Pixel 2 API 28");
//					caps.setCapability("automationName", "UiAutomator2");
//					//caps.setCapability("app", APP_ANDROID);
//					caps.setCapability("appPackage","letsallapp.labh.stage");
//					caps.setCapability("appActivity", "letsallapp.activity.MainActivity");
//					caps.setCapability("udid",  Constants.udid);
//					caps.setCapability("systemPort", params.getSystemPort());
//					caps.setCapability("chromeDriverPort", params.getChromeDriverPort());
//					if(params.getEmulator().equalsIgnoreCase("true")) {
//						caps.setCapability("avd", params.getDeviceName());
//						caps.setCapability("avdLaunchTimeout", 120000);
//					}
//					String androidAppUrl = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test"
//							+ File.separator + "resources" + File.separator + "apps" + File.separator + "app-labhStage29DecV1 (1).apk";
//					utils.log().info("appUrl is" + androidAppUrl);
//					
//					
//				//	String androidAppUrl ="D:\\apk\\app-labh_stage-release_v2.apk";
//					caps.setCapability("app", androidAppUrl);
//				}
//				
//				break;
		
		
			GlobalParamsAppium params = new GlobalParamsAppium();
			Properties props = new PropertyManager().getProps();

			try{
				utils.log().info("getting capabilities");
				DesiredCapabilities caps = new DesiredCapabilities();
				caps.setCapability(MobileCapabilityType.PLATFORM_NAME, params.getPlatformName());
				caps.setCapability(MobileCapabilityType.UDID, params.getUDID());
				caps.setCapability(MobileCapabilityType.DEVICE_NAME, params.getDeviceName());
				caps.setCapability("unicodeKeyboard", "true");                                     
				caps.setCapability("resetKeyboard", "true");

				
				/*caps.setCapability("chromedriverExecutable",
						"C:\\Users\\Vikrant.Gaurav\\Downloads\\chromedriver_win32 (8)");*/
				
				
				switch(params.getPlatformName()){
				case "Android":
					caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, props.getProperty("android.automationName"));
					if(!Constants.isAWS) {
						
						
					
					
					
					/*//	caps.setCapability("appWaitActivity", Constants.appactivity); 
					   caps.setCapability("appPackage", Constants.apppackage);
					 //  caps.setCapability("appActivity", Constants.appactivity);
					   caps.setCapability("appWaitActivity", "Constants.apppackage");
						caps.setCapability("platformName",  Constants.platformName);
						caps.setCapability("platformVersion",  Constants.platformVersion);*/
						
						
						
						
						
						caps.setCapability("platformName", "Android");
						caps.setCapability("deviceName", "Pixel 2 API 28");
						//caps.setCapability("automationName", "UiAutomator2");
						//caps.setCapability("app", APP_ANDROID);
					//	caps.setCapability("appPackage","letsallapp.labh.stage");
					//	caps.setCapability("appActivity", "letsallapp.activity.MainActivity");
					//	caps.setCapability("udid",  Constants.udid);
						caps.setCapability("systemPort", params.getSystemPort());
						caps.setCapability("chromeDriverPort", params.getChromeDriverPort());
						if(params.getEmulator().equalsIgnoreCase("true")) {
							caps.setCapability("avd", params.getDeviceName());
							caps.setCapability("avdLaunchTimeout", 120000);
						}
						String androidAppUrl = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test"
								+ File.separator + "resources" + File.separator + "apps" + File.separator + "app-ibb_stage-release1.apk";
						utils.log().info("appUrl is" + androidAppUrl);
						
						caps.setCapability("app", androidAppUrl);
					}
					
					break;
				
				
			case "iOS":
				caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, props.getProperty("iOS.automationName"));
				if(!Constants.isAWS) {
					//String iOSAppUrl = getClass().getResource(props.getProperty("iOSAppLocation")).getFile();
					String iOSAppUrl = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test"
							+ File.separator + "resources" + File.separator + "apps" + File.separator + "SwagLabsMobileApp.app";
					utils.log().info("appUrl is" + iOSAppUrl);
					caps.setCapability("bundleId", props.getProperty("iOS.bundleId"));
					caps.setCapability("wdaLocalPort", params.getWdaLocalPort());
					caps.setCapability("webkitDebugProxyPort", params.getWebkitDebugProxyPort());
					caps.setCapability("app", iOSAppUrl);
				}
				break;
			}
			return caps;
		} catch(Exception e){
			e.printStackTrace();
			utils.log().fatal("Failed to load capabilities. ABORT!!" + e.toString());
			throw e;
		}
	}
}

